// Oppgave 2.2
public class Gravity {

    public static void main (String[] args) {
        System.out.println("---- What is my weight on the moon? ----");
        double earthWeight = 64;
        double moonWeight = earthWeight * 0.165;

        System.out.println("My weight on the moon is: " + moonWeight + "kg");
    }
}
